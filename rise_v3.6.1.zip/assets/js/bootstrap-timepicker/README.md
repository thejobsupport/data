Timepicker for Twitter Bootstrap 3.x
=======

A simple timepicker component for Twitter Bootstrap.

This project is no longer maintained. If you would like to adopt it, please let me know. I started grad-school and just don't have the time anymore.

Fork of <a href="http://m3wolf.github.com/bootstrap3-timepicker">m3wolf / bootstrap3-timepicker</a>, with updated bootstrap classes.

