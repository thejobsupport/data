//js/bootstrap-timepicker.js
Added custom icon in line #258, #260, #263 & #267

//js/bootstrap-timepicker.min.js
Added custom icon in line #5 (chevron-up and chevron-down icon)

To fix icon issue.