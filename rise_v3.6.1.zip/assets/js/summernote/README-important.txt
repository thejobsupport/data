# Added btn-close and m-0 class for modal close button. 

# Changed data-bs-dismiss with data-dismiss for closing modal.

# Added custom functions for dropdowns

# Added dropdown-item class with dropdown list items